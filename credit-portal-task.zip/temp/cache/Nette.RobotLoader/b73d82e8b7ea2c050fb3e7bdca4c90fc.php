<?php
return array (
  0 => 
  array (
    'App\\Controls\\BaseControl' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\controls\\BaseControl.php',
      'time' => 1519159481,
    ),
    'App\\Controls\\Comment\\CommentFormControl' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\controls\\Comment\\CommentFormControl.php',
      'time' => 1519228820,
    ),
    'App\\Controls\\Comment\\CommentListControl' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\controls\\Comment\\CommentListControl.php',
      'time' => 1519232656,
    ),
    'App\\Controls\\Comment\\ICommentFormControlFactory' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\controls\\Comment\\ICommentFormControlFactory.php',
      'time' => 1519158731,
    ),
    'App\\Controls\\Comment\\ICommentListControlFactory' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\controls\\Comment\\ICommentListControlFactory.php',
      'time' => 1519159732,
    ),
    'App\\Forms\\FormFactory' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\forms\\FormFactory.php',
      'time' => 1519148831,
    ),
    'App\\Forms\\PasswordFormFactory' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\forms\\PasswordFormFactory.php',
      'time' => 1519221559,
    ),
    'App\\Forms\\SignInFormFactory' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\forms\\SignInFormFactory.php',
      'time' => 1519210662,
    ),
    'App\\Forms\\SignUpFormFactory' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\forms\\SignUpFormFactory.php',
      'time' => 1519219837,
    ),
    'App\\Forms\\ThreadFormFactory' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\forms\\ThreadFormFactory.php',
      'time' => 1519226305,
    ),
    'App\\Forms\\UserFormFactory' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\forms\\UserFormFactory.php',
      'time' => 1519230584,
    ),
    'App\\Model\\ActionNotAllowedException' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\ActionNotAllowedException.php',
      'time' => 1519148831,
    ),
    'App\\Model\\Comment\\Comment' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Comment\\Comment.php',
      'time' => 1519234641,
    ),
    'App\\Model\\Comment\\CommentFacade' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Comment\\CommentFacade.php',
      'time' => 1519234675,
    ),
    'App\\Model\\Comment\\CommentNotFoundException' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Comment\\CommentNotFoundException.php',
      'time' => 1519137460,
    ),
    'App\\Model\\Comment\\DoctrineCommentRepository' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Comment\\DoctrineCommentRepository.php',
      'time' => 1519137461,
    ),
    'App\\Model\\Comment\\ICommentFacade' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Comment\\ICommentFacade.php',
      'time' => 1519148831,
    ),
    'App\\Model\\Comment\\ICommentRepository' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Comment\\ICommentRepository.php',
      'time' => 1519137460,
    ),
    'App\\Model\\Comment\\NDCommentRepository' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Comment\\NDCommentRepository.php',
      'time' => 1519209199,
    ),
    'App\\Model\\Db\\DoctrinePersister' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Db\\DoctrinePersister.php',
      'time' => 1519229298,
    ),
    'App\\Model\\Db\\EntityNotFoundException' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Db\\EntityNotFoundException.php',
      'time' => 1511906163,
    ),
    'App\\Model\\Db\\IPersister' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Db\\IPersister.php',
      'time' => 1519149000,
    ),
    'App\\Model\\Db\\NDPersister' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Db\\NDPersister.php',
      'time' => 1519209141,
    ),
    'App\\Model\\Db\\TRamseyUuidIdentifier' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Db\\TRamseyUuidIdentifier.php',
      'time' => 1519160469,
    ),
    'App\\Model\\Db\\TransactionManager' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Db\\TransactionManager.php',
      'time' => 1508522185,
    ),
    'App\\Model\\Helpers\\SizeUploadHelper' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Helpers\\SizeUploadHelper.php',
      'time' => 1508589602,
    ),
    'App\\Model\\Helpers\\TimeAgoInWords' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Helpers\\TimeAgoInWords.php',
      'time' => 1519233269,
    ),
    'App\\Model\\Helpers\\TimeAgoInWordsFilter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Helpers\\TimeAgoInWordsFilter.php',
      'time' => 1519143704,
    ),
    'App\\Model\\InvalidArgumentException' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\InvalidArgumentException.php',
      'time' => 1519082669,
    ),
    'App\\Model\\Thread\\DoctrineThreadRepository' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Thread\\DoctrineThreadRepository.php',
      'time' => 1519224669,
    ),
    'App\\Model\\Thread\\IThreadFacade' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Thread\\IThreadFacade.php',
      'time' => 1519225963,
    ),
    'App\\Model\\Thread\\IThreadRepository' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Thread\\IThreadRepository.php',
      'time' => 1519224053,
    ),
    'App\\Model\\Thread\\NDThreadRepository' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Thread\\NDThreadRepository.php',
      'time' => 1519224053,
    ),
    'App\\Model\\Thread\\Thread' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Thread\\Thread.php',
      'time' => 1519226952,
    ),
    'App\\Model\\Thread\\ThreadDuplicateSlugException' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Thread\\ThreadDuplicateSlugException.php',
      'time' => 1519137461,
    ),
    'App\\Model\\Thread\\ThreadFacade' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Thread\\ThreadFacade.php',
      'time' => 1519225963,
    ),
    'App\\Model\\Thread\\ThreadNotFoundException' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\Thread\\ThreadNotFoundException.php',
      'time' => 1519136860,
    ),
    'App\\Model\\User\\Authenticator' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\User\\Authenticator.php',
      'time' => 1519084555,
    ),
    'App\\Model\\User\\DoctrineUserRepository' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\User\\DoctrineUserRepository.php',
      'time' => 1519230306,
    ),
    'App\\Model\\User\\IUserFacade' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\User\\IUserFacade.php',
      'time' => 1519225963,
    ),
    'App\\Model\\User\\IUserRepository' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\User\\IUserRepository.php',
      'time' => 1519230306,
    ),
    'App\\Model\\User\\NDUserRepository' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\User\\NDUserRepository.php',
      'time' => 1519230306,
    ),
    'App\\Model\\User\\PasswordNotSameException' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\User\\PasswordNotSameException.php',
      'time' => 1519220829,
    ),
    'App\\Model\\User\\User' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\User\\User.php',
      'time' => 1519230306,
    ),
    'App\\Model\\User\\UserDuplicateNameException' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\User\\UserDuplicateNameException.php',
      'time' => 1519083991,
    ),
    'App\\Model\\User\\UserFacade' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\User\\UserFacade.php',
      'time' => 1519225963,
    ),
    'App\\Model\\User\\UserNotFoundException' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\model\\User\\UserNotFoundException.php',
      'time' => 1519083991,
    ),
    'App\\Presenters\\BasePresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\presenters\\BasePresenter.php',
      'time' => 1519230519,
    ),
    'App\\Presenters\\Error4xxPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\presenters\\Error4xxPresenter.php',
      'time' => 1519140821,
    ),
    'App\\Presenters\\ErrorPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\presenters\\ErrorPresenter.php',
      'time' => 1519140821,
    ),
    'App\\Presenters\\HomepagePresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\presenters\\HomepagePresenter.php',
      'time' => 1519140821,
    ),
    'App\\Presenters\\PasswordPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\presenters\\PasswordPresenter.php',
      'time' => 1519230519,
    ),
    'App\\Presenters\\SignPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\presenters\\SignPresenter.php',
      'time' => 1519230743,
    ),
    'App\\Presenters\\ThreadAdminEditPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\presenters\\ThreadAdminEditPresenter.php',
      'time' => 1519230519,
    ),
    'App\\Presenters\\ThreadAdminPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\presenters\\ThreadAdminPresenter.php',
      'time' => 1519230519,
    ),
    'App\\Presenters\\ThreadPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\presenters\\ThreadPresenter.php',
      'time' => 1519210122,
    ),
    'App\\Presenters\\UserAdminEditPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\presenters\\UserAdminEditPresenter.php',
      'time' => 1519230399,
    ),
    'App\\Presenters\\UserAdminPresenter' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\presenters\\UserAdminPresenter.php',
      'time' => 1519230519,
    ),
    'App\\Router\\RouterFactory' => 
    array (
      'file' => 'C:\\xampp\\htdocs\\credit-portal-task\\tests/../app\\router\\RouterFactory.php',
      'time' => 1519220829,
    ),
  ),
  1 => NULL,
);
