<?php
// source: C:\xampp\htdocs\credit-portal-task\app/config/config.neon 
// source: C:\xampp\htdocs\credit-portal-task\app/config/config.local.neon 
// source: C:\xampp\htdocs\credit-portal-task\app/config/config.nd.neon 

class Container_d4cafb4653 extends Nette\DI\Container
{
	protected $meta = [
		'types' => [
			'Nette\Application\Application' => [1 => ['application.application']],
			'Nette\Application\IPresenterFactory' => [1 => ['application.presenterFactory']],
			'Nette\Application\LinkGenerator' => [1 => ['application.linkGenerator']],
			'Nette\Caching\Storages\IJournal' => [1 => ['cache.journal']],
			'Nette\Caching\IStorage' => [1 => ['cache.storage']],
			'Nette\Database\Connection' => [1 => ['database.default.connection']],
			'Nette\Database\IStructure' => [1 => ['database.default.structure']],
			'Nette\Database\Structure' => [1 => ['database.default.structure']],
			'Nette\Database\IConventions' => [1 => ['database.default.conventions']],
			'Nette\Database\Conventions\DiscoveredConventions' => [1 => ['database.default.conventions']],
			'Nette\Database\Context' => [1 => ['database.default.context']],
			'Nette\Http\RequestFactory' => [1 => ['http.requestFactory']],
			'Nette\Http\IRequest' => [1 => ['http.request']],
			'Nette\Http\Request' => [1 => ['http.request']],
			'Nette\Http\IResponse' => [1 => ['http.response']],
			'Nette\Http\Response' => [1 => ['http.response']],
			'Nette\Http\Context' => [1 => ['http.context']],
			'Nette\Bridges\ApplicationLatte\ILatteFactory' => [1 => ['latte.latteFactory']],
			'Nette\Application\UI\ITemplateFactory' => [1 => ['latte.templateFactory']],
			'Nette\Mail\IMailer' => [1 => ['mail.mailer']],
			'Nette\Application\IRouter' => [1 => ['routing.router']],
			'Nette\Security\IUserStorage' => [1 => ['security.userStorage']],
			'Nette\Security\User' => [1 => ['security.user']],
			'Nette\Http\Session' => [1 => ['session.session']],
			'Tracy\ILogger' => [1 => ['tracy.logger']],
			'Tracy\BlueScreen' => [1 => ['tracy.blueScreen']],
			'Tracy\Bar' => [1 => ['tracy.bar']],
			'IteratorAggregate' => [1 => ['console.helperSet']],
			'Traversable' => [1 => ['console.helperSet']],
			'Symfony\Component\Console\Helper\HelperSet' => [1 => ['console.helperSet']],
			'Symfony\Component\Console\Application' => [1 => ['console.application']],
			'Kdyby\Console\Application' => [1 => ['console.application']],
			'Kdyby\Events\EventManager' => [1 => ['events.manager']],
			'Doctrine\Common\EventManager' => [1 => ['events.manager']],
			'Kdyby\Events\LazyEventManager' => [1 => ['events.manager']],
			'WebLoader\IOutputNamingConvention' => [
				1 => ['webloader.cssNamingConvention', 'webloader.jsNamingConvention'],
			],
			'WebLoader\DefaultOutputNamingConvention' => [
				1 => ['webloader.cssNamingConvention', 'webloader.jsNamingConvention'],
			],
			'Tracy\IBarPanel' => [1 => ['webloader.tracyPanel']],
			'WebLoader\Nette\Diagnostics\Panel' => [1 => ['webloader.tracyPanel']],
			'WebLoader\IFileCollection' => [1 => ['webloader.cssFrontendFiles', 'webloader.jsFrontendFiles']],
			'WebLoader\FileCollection' => [1 => ['webloader.cssFrontendFiles', 'webloader.jsFrontendFiles']],
			'WebLoader\Compiler' => [
				1 => ['webloader.cssFrontendCompiler', 'webloader.jsFrontendCompiler'],
			],
			'WebLoader\Nette\LoaderFactory' => [1 => ['webloader.factory']],
			'App\Controls\Comment\ICommentFormControlFactory' => [1 => ['35_App_Controls_Comment_ICommentFormControlFactory']],
			'App\Controls\Comment\ICommentListControlFactory' => [1 => ['36_App_Controls_Comment_ICommentListControlFactory']],
			'App\Forms\FormFactory' => [1 => ['37_App_Forms_FormFactory']],
			'App\Forms\PasswordFormFactory' => [1 => ['38_App_Forms_PasswordFormFactory']],
			'App\Forms\SignInFormFactory' => [1 => ['39_App_Forms_SignInFormFactory']],
			'App\Forms\SignUpFormFactory' => [1 => ['40_App_Forms_SignUpFormFactory']],
			'App\Forms\ThreadFormFactory' => [1 => ['41_App_Forms_ThreadFormFactory']],
			'App\Forms\UserFormFactory' => [1 => ['42_App_Forms_UserFormFactory']],
			'App\Model\Comment\ICommentFacade' => [1 => ['43_App_Model_Comment_CommentFacade']],
			'App\Model\Comment\CommentFacade' => [1 => ['43_App_Model_Comment_CommentFacade']],
			'App\Model\Comment\ICommentRepository' => [1 => ['44_App_Model_Comment_NDCommentRepository']],
			'App\Model\Comment\NDCommentRepository' => [1 => ['44_App_Model_Comment_NDCommentRepository']],
			'App\Model\Db\IPersister' => [1 => ['45_App_Model_Db_NDPersister']],
			'App\Model\Db\NDPersister' => [1 => ['45_App_Model_Db_NDPersister']],
			'App\Model\Helpers\TimeAgoInWordsFilter' => [1 => ['46_App_Model_Helpers_TimeAgoInWordsFilter']],
			'App\Model\Thread\IThreadRepository' => [1 => ['47_App_Model_Thread_NDThreadRepository']],
			'App\Model\Thread\NDThreadRepository' => [1 => ['47_App_Model_Thread_NDThreadRepository']],
			'App\Model\Thread\IThreadFacade' => [1 => ['48_App_Model_Thread_ThreadFacade']],
			'App\Model\Thread\ThreadFacade' => [1 => ['48_App_Model_Thread_ThreadFacade']],
			'Nette\Security\IAuthenticator' => [1 => ['49_App_Model_User_Authenticator']],
			'App\Model\User\Authenticator' => [1 => ['49_App_Model_User_Authenticator']],
			'App\Model\User\IUserRepository' => [1 => ['50_App_Model_User_NDUserRepository']],
			'App\Model\User\NDUserRepository' => [1 => ['50_App_Model_User_NDUserRepository']],
			'App\Model\User\IUserFacade' => [1 => ['51_App_Model_User_UserFacade']],
			'App\Model\User\UserFacade' => [1 => ['51_App_Model_User_UserFacade']],
			'App\Router\RouterFactory' => [1 => ['52_App_Router_RouterFactory']],
			'Joseki\Webloader\CssMinFilter' => [1 => ['cssMinFilter']],
			'Joseki\Webloader\JsMinFilter' => [1 => ['jsMinFilter']],
			'WebLoader\Filter\CssUrlsFilter' => [1 => ['wlCssFilter']],
			'App\Presenters\BasePresenter' => [
				1 => [
					'application.1',
					'application.3',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
					'application.9',
					'application.10',
				],
			],
			'Nette\Application\UI\Presenter' => [
				[
					'application.1',
					'application.3',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
					'application.9',
					'application.10',
					'application.11',
				],
			],
			'Nette\Application\UI\Control' => [
				[
					'application.1',
					'application.3',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
					'application.9',
					'application.10',
					'application.11',
				],
			],
			'Nette\Application\UI\Component' => [
				[
					'application.1',
					'application.3',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
					'application.9',
					'application.10',
					'application.11',
				],
			],
			'Nette\ComponentModel\Container' => [
				[
					'application.1',
					'application.3',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
					'application.9',
					'application.10',
					'application.11',
				],
			],
			'Nette\ComponentModel\Component' => [
				[
					'application.1',
					'application.3',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
					'application.9',
					'application.10',
					'application.11',
				],
			],
			'Nette\Application\UI\IRenderable' => [
				[
					'application.1',
					'application.3',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
					'application.9',
					'application.10',
					'application.11',
				],
			],
			'Nette\ComponentModel\IContainer' => [
				[
					'application.1',
					'application.3',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
					'application.9',
					'application.10',
					'application.11',
				],
			],
			'Nette\ComponentModel\IComponent' => [
				[
					'application.1',
					'application.3',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
					'application.9',
					'application.10',
					'application.11',
				],
			],
			'Nette\Application\UI\ISignalReceiver' => [
				[
					'application.1',
					'application.3',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
					'application.9',
					'application.10',
					'application.11',
				],
			],
			'Nette\Application\UI\IStatePersistent' => [
				[
					'application.1',
					'application.3',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
					'application.9',
					'application.10',
					'application.11',
				],
			],
			'ArrayAccess' => [
				[
					'application.1',
					'application.3',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
					'application.9',
					'application.10',
					'application.11',
				],
			],
			'Nette\Application\IPresenter' => [
				[
					'application.1',
					'application.2',
					'application.3',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
					'application.9',
					'application.10',
					'application.11',
					'application.12',
					'application.13',
				],
			],
			'App\Presenters\Error4xxPresenter' => [1 => ['application.1']],
			'App\Presenters\ErrorPresenter' => [1 => ['application.2']],
			'App\Presenters\HomepagePresenter' => [1 => ['application.3']],
			'App\Presenters\PasswordPresenter' => [1 => ['application.4']],
			'App\Presenters\SignPresenter' => [1 => ['application.5']],
			'App\Presenters\ThreadAdminEditPresenter' => [1 => ['application.6']],
			'App\Presenters\ThreadAdminPresenter' => [1 => ['application.7']],
			'App\Presenters\ThreadPresenter' => [1 => ['application.8']],
			'App\Presenters\UserAdminEditPresenter' => [1 => ['application.9']],
			'App\Presenters\UserAdminPresenter' => [1 => ['application.10']],
			'KdybyModule\CliPresenter' => [1 => ['application.11']],
			'NetteModule\ErrorPresenter' => [1 => ['application.12']],
			'NetteModule\MicroPresenter' => [1 => ['application.13']],
			'Nette\DI\Container' => [1 => ['container']],
			'WebLoader\LoaderFactory' => [1 => ['webloader.factory']],
		],
		'services' => [
			'35_App_Controls_Comment_ICommentFormControlFactory' => 'App\Controls\Comment\CommentFormControl',
			'36_App_Controls_Comment_ICommentListControlFactory' => 'App\Controls\Comment\CommentListControl',
			'37_App_Forms_FormFactory' => 'App\Forms\FormFactory',
			'38_App_Forms_PasswordFormFactory' => 'App\Forms\PasswordFormFactory',
			'39_App_Forms_SignInFormFactory' => 'App\Forms\SignInFormFactory',
			'40_App_Forms_SignUpFormFactory' => 'App\Forms\SignUpFormFactory',
			'41_App_Forms_ThreadFormFactory' => 'App\Forms\ThreadFormFactory',
			'42_App_Forms_UserFormFactory' => 'App\Forms\UserFormFactory',
			'43_App_Model_Comment_CommentFacade' => 'App\Model\Comment\CommentFacade',
			'44_App_Model_Comment_NDCommentRepository' => 'App\Model\Comment\NDCommentRepository',
			'45_App_Model_Db_NDPersister' => 'App\Model\Db\NDPersister',
			'46_App_Model_Helpers_TimeAgoInWordsFilter' => 'App\Model\Helpers\TimeAgoInWordsFilter',
			'47_App_Model_Thread_NDThreadRepository' => 'App\Model\Thread\NDThreadRepository',
			'48_App_Model_Thread_ThreadFacade' => 'App\Model\Thread\ThreadFacade',
			'49_App_Model_User_Authenticator' => 'App\Model\User\Authenticator',
			'50_App_Model_User_NDUserRepository' => 'App\Model\User\NDUserRepository',
			'51_App_Model_User_UserFacade' => 'App\Model\User\UserFacade',
			'52_App_Router_RouterFactory' => 'App\Router\RouterFactory',
			'application.1' => 'App\Presenters\Error4xxPresenter',
			'application.10' => 'App\Presenters\UserAdminPresenter',
			'application.11' => 'KdybyModule\CliPresenter',
			'application.12' => 'NetteModule\ErrorPresenter',
			'application.13' => 'NetteModule\MicroPresenter',
			'application.2' => 'App\Presenters\ErrorPresenter',
			'application.3' => 'App\Presenters\HomepagePresenter',
			'application.4' => 'App\Presenters\PasswordPresenter',
			'application.5' => 'App\Presenters\SignPresenter',
			'application.6' => 'App\Presenters\ThreadAdminEditPresenter',
			'application.7' => 'App\Presenters\ThreadAdminPresenter',
			'application.8' => 'App\Presenters\ThreadPresenter',
			'application.9' => 'App\Presenters\UserAdminEditPresenter',
			'application.application' => 'Nette\Application\Application',
			'application.linkGenerator' => 'Nette\Application\LinkGenerator',
			'application.presenterFactory' => 'Nette\Application\IPresenterFactory',
			'cache.journal' => 'Nette\Caching\Storages\IJournal',
			'cache.storage' => 'Nette\Caching\IStorage',
			'console.application' => 'Kdyby\Console\Application',
			'console.helperSet' => 'Symfony\Component\Console\Helper\HelperSet',
			'container' => 'Nette\DI\Container',
			'cssMinFilter' => 'Joseki\Webloader\CssMinFilter',
			'database.default.connection' => 'Nette\Database\Connection',
			'database.default.context' => 'Nette\Database\Context',
			'database.default.conventions' => 'Nette\Database\Conventions\DiscoveredConventions',
			'database.default.structure' => 'Nette\Database\Structure',
			'events.manager' => 'Kdyby\Events\LazyEventManager',
			'http.context' => 'Nette\Http\Context',
			'http.request' => 'Nette\Http\Request',
			'http.requestFactory' => 'Nette\Http\RequestFactory',
			'http.response' => 'Nette\Http\Response',
			'jsMinFilter' => 'Joseki\Webloader\JsMinFilter',
			'latte.latteFactory' => 'Latte\Engine',
			'latte.templateFactory' => 'Nette\Application\UI\ITemplateFactory',
			'mail.mailer' => 'Nette\Mail\IMailer',
			'routing.router' => 'Nette\Application\IRouter',
			'security.user' => 'Nette\Security\User',
			'security.userStorage' => 'Nette\Security\IUserStorage',
			'session.session' => 'Nette\Http\Session',
			'tracy.bar' => 'Tracy\Bar',
			'tracy.blueScreen' => 'Tracy\BlueScreen',
			'tracy.logger' => 'Tracy\ILogger',
			'webloader.cssFrontendCompiler' => 'WebLoader\Compiler',
			'webloader.cssFrontendFiles' => 'WebLoader\FileCollection',
			'webloader.cssNamingConvention' => 'WebLoader\DefaultOutputNamingConvention',
			'webloader.factory' => 'WebLoader\Nette\LoaderFactory',
			'webloader.jsFrontendCompiler' => 'WebLoader\Compiler',
			'webloader.jsFrontendFiles' => 'WebLoader\FileCollection',
			'webloader.jsNamingConvention' => 'WebLoader\DefaultOutputNamingConvention',
			'webloader.tracyPanel' => 'WebLoader\Nette\Diagnostics\Panel',
			'wlCssFilter' => 'WebLoader\Filter\CssUrlsFilter',
		],
		'tags' => [
			'inject' => [
				'application.1' => true,
				'application.10' => true,
				'application.11' => true,
				'application.12' => true,
				'application.13' => true,
				'application.2' => true,
				'application.3' => true,
				'application.4' => true,
				'application.5' => true,
				'application.6' => true,
				'application.7' => true,
				'application.8' => true,
				'application.9' => true,
			],
			'nette.presenter' => [
				'application.1' => 'App\Presenters\Error4xxPresenter',
				'application.10' => 'App\Presenters\UserAdminPresenter',
				'application.11' => 'KdybyModule\CliPresenter',
				'application.12' => 'NetteModule\ErrorPresenter',
				'application.13' => 'NetteModule\MicroPresenter',
				'application.2' => 'App\Presenters\ErrorPresenter',
				'application.3' => 'App\Presenters\HomepagePresenter',
				'application.4' => 'App\Presenters\PasswordPresenter',
				'application.5' => 'App\Presenters\SignPresenter',
				'application.6' => 'App\Presenters\ThreadAdminEditPresenter',
				'application.7' => 'App\Presenters\ThreadAdminPresenter',
				'application.8' => 'App\Presenters\ThreadPresenter',
				'application.9' => 'App\Presenters\UserAdminEditPresenter',
			],
		],
		'aliases' => [
			'application' => 'application.application',
			'cacheStorage' => 'cache.storage',
			'database.default' => 'database.default.connection',
			'httpRequest' => 'http.request',
			'httpResponse' => 'http.response',
			'nette.cacheJournal' => 'cache.journal',
			'nette.database.default' => 'database.default',
			'nette.database.default.context' => 'database.default.context',
			'nette.httpContext' => 'http.context',
			'nette.httpRequestFactory' => 'http.requestFactory',
			'nette.latteFactory' => 'latte.latteFactory',
			'nette.mailer' => 'mail.mailer',
			'nette.presenterFactory' => 'application.presenterFactory',
			'nette.templateFactory' => 'latte.templateFactory',
			'nette.userStorage' => 'security.userStorage',
			'router' => 'routing.router',
			'session' => 'session.session',
			'user' => 'security.user',
		],
	];


	public function __construct(array $params = [])
	{
		$this->parameters = $params;
		$this->parameters += [
			'appDir' => 'C:\xampp\htdocs\credit-portal-task\app',
			'wwwDir' => 'C:\xampp\htdocs\credit-portal-task\www',
			'debugMode' => true,
			'productionMode' => false,
			'consoleMode' => false,
			'tempDir' => 'C:\xampp\htdocs\credit-portal-task\app/../temp',
			'webloader' => [
				'jsDefaults' => [
					'checkLastModified' => true,
					'debug' => false,
					'sourceDir' => 'C:\xampp\htdocs\credit-portal-task\www/js',
					'tempDir' => 'C:\xampp\htdocs\credit-portal-task\www/webtemp',
					'tempPath' => 'webtemp',
					'files' => [],
					'watchFiles' => [],
					'remoteFiles' => [],
					'filters' => [],
					'fileFilters' => [],
					'joinFiles' => true,
					'namingConvention' => '@webloader.jsNamingConvention',
				],
				'cssDefaults' => [
					'checkLastModified' => true,
					'debug' => false,
					'sourceDir' => 'C:\xampp\htdocs\credit-portal-task\www/css',
					'tempDir' => 'C:\xampp\htdocs\credit-portal-task\www/webtemp',
					'tempPath' => 'webtemp',
					'files' => [],
					'watchFiles' => [],
					'remoteFiles' => [],
					'filters' => [],
					'fileFilters' => [],
					'joinFiles' => true,
					'namingConvention' => '@webloader.cssNamingConvention',
				],
				'js' => [
					'frontend' => [
						'remoteFiles' => ['https://code.jquery.com/jquery-3.1.1.min.js'],
						'files' => [
							'bootstrap.min.js',
							'nette.ajax.js',
							'nette.init.js',
							'confirm.ajax.js',
							'form-protection.ajax.js',
							'happy.ajax.js',
							'live-form-validation.js',
							'happy.min.js',
							'datagrid.js',
							'datagrid-spinners.min.js',
							'main.js',
						],
						'filtres' => ['@jsMinFilter'],
					],
				],
				'css' => [
					'frontend' => [
						'remoteFiles' => null,
						'files' => [
							'bootstrap.min.css',
							'happy.min.css',
							'datagrid.min.css',
							'datagrid-spinners.min.css',
							'style.css',
						],
						'filters' => ['@wlCssFilter', '@cssMinFilter'],
					],
				],
				'debugger' => true,
			],
		];
	}


	public function createService__35_App_Controls_Comment_ICommentFormControlFactory(): App\Controls\Comment\ICommentFormControlFactory
	{
		return new class ($this) implements App\Controls\Comment\ICommentFormControlFactory {
			private $container;


			public function __construct(Container_d4cafb4653 $container)
			{
				$this->container = $container;
			}


			public function create(App\Model\Thread\Thread $thread): App\Controls\Comment\CommentFormControl
			{
				$service = new App\Controls\Comment\CommentFormControl($thread, $this->container->getService('37_App_Forms_FormFactory'),
					$this->container->getService('43_App_Model_Comment_CommentFacade'), $this->container->getService('39_App_Forms_SignInFormFactory'),
					$this->container->getService('50_App_Model_User_NDUserRepository'), $this->container->getService('44_App_Model_Comment_NDCommentRepository'));
				$service->setUser($this->container->getService('security.user'));
				$service->onPosted = $this->container->getService('events.manager')->createEvent(['App\Controls\Comment\CommentFormControl', 'onPosted'],
					$service->onPosted, null, false);
				$service->onError = $this->container->getService('events.manager')->createEvent(['App\Controls\Comment\CommentFormControl', 'onError'],
					$service->onError, null, false);
				$service->onLoggedIn = $this->container->getService('events.manager')->createEvent(['App\Controls\Comment\CommentFormControl', 'onLoggedIn'],
					$service->onLoggedIn, null, false);
				$service->onAnchor = $this->container->getService('events.manager')->createEvent(['App\Controls\Comment\CommentFormControl', 'onAnchor'],
					$service->onAnchor, null, false);
				return $service;
			}
		};
	}


	public function createService__36_App_Controls_Comment_ICommentListControlFactory(): App\Controls\Comment\ICommentListControlFactory
	{
		return new class ($this) implements App\Controls\Comment\ICommentListControlFactory {
			private $container;


			public function __construct(Container_d4cafb4653 $container)
			{
				$this->container = $container;
			}


			public function create(App\Model\Thread\Thread $thread): App\Controls\Comment\CommentListControl
			{
				$service = new App\Controls\Comment\CommentListControl($thread, $this->container->getService('43_App_Model_Comment_CommentFacade'),
					$this->container->getService('44_App_Model_Comment_NDCommentRepository'));
				$service->setUser($this->container->getService('security.user'));
				$service->onAnchor = $this->container->getService('events.manager')->createEvent(['App\Controls\Comment\CommentListControl', 'onAnchor'],
					$service->onAnchor, null, false);
				return $service;
			}
		};
	}


	public function createService__37_App_Forms_FormFactory(): App\Forms\FormFactory
	{
		$service = new App\Forms\FormFactory;
		return $service;
	}


	public function createService__38_App_Forms_PasswordFormFactory(): App\Forms\PasswordFormFactory
	{
		$service = new App\Forms\PasswordFormFactory($this->getService('37_App_Forms_FormFactory'),
			$this->getService('51_App_Model_User_UserFacade'), $this->getService('security.user'));
		return $service;
	}


	public function createService__39_App_Forms_SignInFormFactory(): App\Forms\SignInFormFactory
	{
		$service = new App\Forms\SignInFormFactory($this->getService('37_App_Forms_FormFactory'),
			$this->getService('security.user'));
		return $service;
	}


	public function createService__40_App_Forms_SignUpFormFactory(): App\Forms\SignUpFormFactory
	{
		$service = new App\Forms\SignUpFormFactory($this->getService('37_App_Forms_FormFactory'),
			$this->getService('51_App_Model_User_UserFacade'), $this->getService('security.user'));
		return $service;
	}


	public function createService__41_App_Forms_ThreadFormFactory(): App\Forms\ThreadFormFactory
	{
		$service = new App\Forms\ThreadFormFactory($this->getService('37_App_Forms_FormFactory'),
			$this->getService('48_App_Model_Thread_ThreadFacade'));
		return $service;
	}


	public function createService__42_App_Forms_UserFormFactory(): App\Forms\UserFormFactory
	{
		$service = new App\Forms\UserFormFactory($this->getService('37_App_Forms_FormFactory'),
			$this->getService('51_App_Model_User_UserFacade'));
		return $service;
	}


	public function createService__43_App_Model_Comment_CommentFacade(): App\Model\Comment\CommentFacade
	{
		$service = new App\Model\Comment\CommentFacade($this->getService('45_App_Model_Db_NDPersister'),
			$this->getService('security.user'), $this->getService('44_App_Model_Comment_NDCommentRepository'));
		return $service;
	}


	public function createService__44_App_Model_Comment_NDCommentRepository(): App\Model\Comment\NDCommentRepository
	{
		$service = new App\Model\Comment\NDCommentRepository($this->getService('database.default.context'));
		return $service;
	}


	public function createService__45_App_Model_Db_NDPersister(): App\Model\Db\NDPersister
	{
		$service = new App\Model\Db\NDPersister($this->getService('database.default.context'));
		return $service;
	}


	public function createService__46_App_Model_Helpers_TimeAgoInWordsFilter(): App\Model\Helpers\TimeAgoInWordsFilter
	{
		$service = new App\Model\Helpers\TimeAgoInWordsFilter;
		return $service;
	}


	public function createService__47_App_Model_Thread_NDThreadRepository(): App\Model\Thread\NDThreadRepository
	{
		$service = new App\Model\Thread\NDThreadRepository($this->getService('database.default.context'),
			$this->getService('44_App_Model_Comment_NDCommentRepository'));
		return $service;
	}


	public function createService__48_App_Model_Thread_ThreadFacade(): App\Model\Thread\ThreadFacade
	{
		$service = new App\Model\Thread\ThreadFacade($this->getService('45_App_Model_Db_NDPersister'),
			$this->getService('security.user'), $this->getService('47_App_Model_Thread_NDThreadRepository'));
		return $service;
	}


	public function createService__49_App_Model_User_Authenticator(): App\Model\User\Authenticator
	{
		$service = new App\Model\User\Authenticator($this->getService('50_App_Model_User_NDUserRepository'),
			$this->getService('45_App_Model_Db_NDPersister'));
		return $service;
	}


	public function createService__50_App_Model_User_NDUserRepository(): App\Model\User\NDUserRepository
	{
		$service = new App\Model\User\NDUserRepository($this->getService('database.default.context'));
		return $service;
	}


	public function createService__51_App_Model_User_UserFacade(): App\Model\User\UserFacade
	{
		$service = new App\Model\User\UserFacade($this->getService('45_App_Model_Db_NDPersister'),
			$this->getService('security.user'), $this->getService('50_App_Model_User_NDUserRepository'));
		return $service;
	}


	public function createService__52_App_Router_RouterFactory(): App\Router\RouterFactory
	{
		$service = new App\Router\RouterFactory($this->getService('47_App_Model_Thread_NDThreadRepository'));
		return $service;
	}


	public function createServiceApplication__1(): App\Presenters\Error4xxPresenter
	{
		$service = new App\Presenters\Error4xxPresenter;
		$service->injectPrimary($this, $this->getService('application.presenterFactory'),
			$this->getService('routing.router'), $this->getService('http.request'),
			$this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->webLoader = $this->getService('webloader.factory');
		$service->invalidLinkMode = 5;
		$service->onShutdown = $this->getService('events.manager')->createEvent(['App\Presenters\Error4xxPresenter', 'onShutdown'],
			$service->onShutdown, null, false);
		$service->onAnchor = $this->getService('events.manager')->createEvent(['App\Presenters\Error4xxPresenter', 'onAnchor'],
			$service->onAnchor, null, false);
		return $service;
	}


	public function createServiceApplication__10(): App\Presenters\UserAdminPresenter
	{
		$service = new App\Presenters\UserAdminPresenter($this->getService('50_App_Model_User_NDUserRepository'));
		$service->injectPrimary($this, $this->getService('application.presenterFactory'),
			$this->getService('routing.router'), $this->getService('http.request'),
			$this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->webLoader = $this->getService('webloader.factory');
		$service->invalidLinkMode = 5;
		$service->onShutdown = $this->getService('events.manager')->createEvent(['App\Presenters\UserAdminPresenter', 'onShutdown'],
			$service->onShutdown, null, false);
		$service->onAnchor = $this->getService('events.manager')->createEvent(['App\Presenters\UserAdminPresenter', 'onAnchor'],
			$service->onAnchor, null, false);
		return $service;
	}


	public function createServiceApplication__11(): KdybyModule\CliPresenter
	{
		$service = new KdybyModule\CliPresenter;
		$service->injectPrimary($this, $this->getService('application.presenterFactory'),
			$this->getService('routing.router'), $this->getService('http.request'),
			$this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->injectConsole($this->getService('console.application'), $this->getService('application.application'));
		$service->invalidLinkMode = 5;
		$service->onShutdown = $this->getService('events.manager')->createEvent(['KdybyModule\CliPresenter', 'onShutdown'],
			$service->onShutdown, null, false);
		$service->onAnchor = $this->getService('events.manager')->createEvent(['KdybyModule\CliPresenter', 'onAnchor'],
			$service->onAnchor, null, false);
		return $service;
	}


	public function createServiceApplication__12(): NetteModule\ErrorPresenter
	{
		$service = new NetteModule\ErrorPresenter($this->getService('tracy.logger'));
		return $service;
	}


	public function createServiceApplication__13(): NetteModule\MicroPresenter
	{
		$service = new NetteModule\MicroPresenter($this, $this->getService('http.request'),
			$this->getService('routing.router'));
		return $service;
	}


	public function createServiceApplication__2(): App\Presenters\ErrorPresenter
	{
		$service = new App\Presenters\ErrorPresenter($this->getService('tracy.logger'));
		return $service;
	}


	public function createServiceApplication__3(): App\Presenters\HomepagePresenter
	{
		$service = new App\Presenters\HomepagePresenter($this->getService('47_App_Model_Thread_NDThreadRepository'));
		$service->injectPrimary($this, $this->getService('application.presenterFactory'),
			$this->getService('routing.router'), $this->getService('http.request'),
			$this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->webLoader = $this->getService('webloader.factory');
		$service->invalidLinkMode = 5;
		$service->onShutdown = $this->getService('events.manager')->createEvent(['App\Presenters\HomepagePresenter', 'onShutdown'],
			$service->onShutdown, null, false);
		$service->onAnchor = $this->getService('events.manager')->createEvent(['App\Presenters\HomepagePresenter', 'onAnchor'],
			$service->onAnchor, null, false);
		return $service;
	}


	public function createServiceApplication__4(): App\Presenters\PasswordPresenter
	{
		$service = new App\Presenters\PasswordPresenter($this->getService('38_App_Forms_PasswordFormFactory'));
		$service->injectPrimary($this, $this->getService('application.presenterFactory'),
			$this->getService('routing.router'), $this->getService('http.request'),
			$this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->webLoader = $this->getService('webloader.factory');
		$service->invalidLinkMode = 5;
		$service->onShutdown = $this->getService('events.manager')->createEvent(['App\Presenters\PasswordPresenter', 'onShutdown'],
			$service->onShutdown, null, false);
		$service->onAnchor = $this->getService('events.manager')->createEvent(['App\Presenters\PasswordPresenter', 'onAnchor'],
			$service->onAnchor, null, false);
		return $service;
	}


	public function createServiceApplication__5(): App\Presenters\SignPresenter
	{
		$service = new App\Presenters\SignPresenter($this->getService('39_App_Forms_SignInFormFactory'),
			$this->getService('40_App_Forms_SignUpFormFactory'));
		$service->injectPrimary($this, $this->getService('application.presenterFactory'),
			$this->getService('routing.router'), $this->getService('http.request'),
			$this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->webLoader = $this->getService('webloader.factory');
		$service->invalidLinkMode = 5;
		$service->onShutdown = $this->getService('events.manager')->createEvent(['App\Presenters\SignPresenter', 'onShutdown'],
			$service->onShutdown, null, false);
		$service->onAnchor = $this->getService('events.manager')->createEvent(['App\Presenters\SignPresenter', 'onAnchor'],
			$service->onAnchor, null, false);
		return $service;
	}


	public function createServiceApplication__6(): App\Presenters\ThreadAdminEditPresenter
	{
		$service = new App\Presenters\ThreadAdminEditPresenter($this->getService('47_App_Model_Thread_NDThreadRepository'),
			$this->getService('41_App_Forms_ThreadFormFactory'));
		$service->injectPrimary($this, $this->getService('application.presenterFactory'),
			$this->getService('routing.router'), $this->getService('http.request'),
			$this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->webLoader = $this->getService('webloader.factory');
		$service->invalidLinkMode = 5;
		$service->onShutdown = $this->getService('events.manager')->createEvent(['App\Presenters\ThreadAdminEditPresenter', 'onShutdown'],
			$service->onShutdown, null, false);
		$service->onAnchor = $this->getService('events.manager')->createEvent(['App\Presenters\ThreadAdminEditPresenter', 'onAnchor'],
			$service->onAnchor, null, false);
		return $service;
	}


	public function createServiceApplication__7(): App\Presenters\ThreadAdminPresenter
	{
		$service = new App\Presenters\ThreadAdminPresenter($this->getService('47_App_Model_Thread_NDThreadRepository'));
		$service->injectPrimary($this, $this->getService('application.presenterFactory'),
			$this->getService('routing.router'), $this->getService('http.request'),
			$this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->webLoader = $this->getService('webloader.factory');
		$service->invalidLinkMode = 5;
		$service->onShutdown = $this->getService('events.manager')->createEvent(['App\Presenters\ThreadAdminPresenter', 'onShutdown'],
			$service->onShutdown, null, false);
		$service->onAnchor = $this->getService('events.manager')->createEvent(['App\Presenters\ThreadAdminPresenter', 'onAnchor'],
			$service->onAnchor, null, false);
		return $service;
	}


	public function createServiceApplication__8(): App\Presenters\ThreadPresenter
	{
		$service = new App\Presenters\ThreadPresenter($this->getService('44_App_Model_Comment_NDCommentRepository'),
			$this->getService('35_App_Controls_Comment_ICommentFormControlFactory'),
			$this->getService('36_App_Controls_Comment_ICommentListControlFactory'),
			$this->getService('43_App_Model_Comment_CommentFacade'));
		$service->injectPrimary($this, $this->getService('application.presenterFactory'),
			$this->getService('routing.router'), $this->getService('http.request'),
			$this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->webLoader = $this->getService('webloader.factory');
		$service->invalidLinkMode = 5;
		$service->onShutdown = $this->getService('events.manager')->createEvent(['App\Presenters\ThreadPresenter', 'onShutdown'],
			$service->onShutdown, null, false);
		$service->onAnchor = $this->getService('events.manager')->createEvent(['App\Presenters\ThreadPresenter', 'onAnchor'],
			$service->onAnchor, null, false);
		return $service;
	}


	public function createServiceApplication__9(): App\Presenters\UserAdminEditPresenter
	{
		$service = new App\Presenters\UserAdminEditPresenter($this->getService('50_App_Model_User_NDUserRepository'),
			$this->getService('42_App_Forms_UserFormFactory'));
		$service->injectPrimary($this, $this->getService('application.presenterFactory'),
			$this->getService('routing.router'), $this->getService('http.request'),
			$this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->webLoader = $this->getService('webloader.factory');
		$service->invalidLinkMode = 5;
		$service->onShutdown = $this->getService('events.manager')->createEvent(['App\Presenters\UserAdminEditPresenter', 'onShutdown'],
			$service->onShutdown, null, false);
		$service->onAnchor = $this->getService('events.manager')->createEvent(['App\Presenters\UserAdminEditPresenter', 'onAnchor'],
			$service->onAnchor, null, false);
		return $service;
	}


	public function createServiceApplication__application(): Nette\Application\Application
	{
		$service = new Nette\Application\Application($this->getService('application.presenterFactory'),
			$this->getService('routing.router'), $this->getService('http.request'),
			$this->getService('http.response'));
		$service->catchExceptions = false;
		$service->errorPresenter = 'Error';
		Nette\Bridges\ApplicationTracy\RoutingPanel::initializePanel($service);
		$this->getService('tracy.bar')->addPanel(new Nette\Bridges\ApplicationTracy\RoutingPanel($this->getService('routing.router'),
			$this->getService('http.request'), $this->getService('application.presenterFactory')));
		$service->onStartup = $this->getService('events.manager')->createEvent(['Nette\Application\Application', 'onStartup'],
			$service->onStartup, null, false);
		$service->onShutdown = $this->getService('events.manager')->createEvent(['Nette\Application\Application', 'onShutdown'],
			$service->onShutdown, null, false);
		$service->onRequest = $this->getService('events.manager')->createEvent(['Nette\Application\Application', 'onRequest'],
			$service->onRequest, null, false);
		$service->onPresenter = $this->getService('events.manager')->createEvent(['Nette\Application\Application', 'onPresenter'],
			$service->onPresenter, null, false);
		$service->onResponse = $this->getService('events.manager')->createEvent(['Nette\Application\Application', 'onResponse'],
			$service->onResponse, null, false);
		$service->onError = $this->getService('events.manager')->createEvent(['Nette\Application\Application', 'onError'],
			$service->onError, null, false);
		return $service;
	}


	public function createServiceApplication__linkGenerator(): Nette\Application\LinkGenerator
	{
		$service = new Nette\Application\LinkGenerator($this->getService('routing.router'),
			$this->getService('http.request')->getUrl(), $this->getService('application.presenterFactory'));
		return $service;
	}


	public function createServiceApplication__presenterFactory(): Nette\Application\IPresenterFactory
	{
		$service = new Nette\Application\PresenterFactory(new Nette\Bridges\ApplicationDI\PresenterFactoryCallback($this, 5, 'C:\xampp\htdocs\credit-portal-task\app/../temp/cache/Nette%5CBridges%5CApplicationDI%5CApplicationExtension'));
		$service->setMapping(['*' => 'App\*Module\Presenters\*Presenter']);
		return $service;
	}


	public function createServiceCache__journal(): Nette\Caching\Storages\IJournal
	{
		$service = new Nette\Caching\Storages\SQLiteJournal('C:\xampp\htdocs\credit-portal-task\app/../temp/cache/journal.s3db');
		return $service;
	}


	public function createServiceCache__storage(): Nette\Caching\IStorage
	{
		$service = new Nette\Caching\Storages\FileStorage('C:\xampp\htdocs\credit-portal-task\app/../temp/cache',
			$this->getService('cache.journal'));
		return $service;
	}


	public function createServiceConsole__application(): Kdyby\Console\Application
	{
		$service = new Kdyby\Console\Application('Nette Framework', 'unknown');
		$service->setHelperSet($this->getService('console.helperSet'));
		$service->injectServiceLocator($this);
		return $service;
	}


	public function createServiceConsole__helperSet(): Symfony\Component\Console\Helper\HelperSet
	{
		$service = new Symfony\Component\Console\Helper\HelperSet;
		$service->set(new Symfony\Component\Console\Helper\ProcessHelper);
		$service->set(new Symfony\Component\Console\Helper\DescriptorHelper);
		$service->set(new Symfony\Component\Console\Helper\FormatterHelper);
		$service->set(new Symfony\Component\Console\Helper\QuestionHelper);
		$service->set(new Symfony\Component\Console\Helper\DebugFormatterHelper);
		$service->set(new Kdyby\Console\Helpers\PresenterHelper($this->getService('application.application')));
		$service->set(new Kdyby\Console\ContainerHelper($this), 'dic');
		return $service;
	}


	public function createServiceContainer(): Nette\DI\Container
	{
		return $this;
	}


	public function createServiceCssMinFilter(): Joseki\Webloader\CssMinFilter
	{
		$service = new Joseki\Webloader\CssMinFilter;
		return $service;
	}


	public function createServiceDatabase__default__connection(): Nette\Database\Connection
	{
		$service = new Nette\Database\Connection('mysql:host=127.0.0.1;dbname=creadit-porta-task',
			'root', null, ['lazy' => true]);
		$this->getService('tracy.blueScreen')->addPanel('Nette\Bridges\DatabaseTracy\ConnectionPanel::renderException');
		Nette\Database\Helpers::createDebugPanel($service, true, 'default');
		$service->onConnect = $this->getService('events.manager')->createEvent(['Nette\Database\Connection', 'onConnect'],
			$service->onConnect, null, false);
		$service->onQuery = $this->getService('events.manager')->createEvent(['Nette\Database\Connection', 'onQuery'],
			$service->onQuery, null, false);
		return $service;
	}


	public function createServiceDatabase__default__context(): Nette\Database\Context
	{
		$service = new Nette\Database\Context($this->getService('database.default.connection'),
			$this->getService('database.default.structure'), $this->getService('database.default.conventions'),
			$this->getService('cache.storage'));
		return $service;
	}


	public function createServiceDatabase__default__conventions(): Nette\Database\Conventions\DiscoveredConventions
	{
		$service = new Nette\Database\Conventions\DiscoveredConventions($this->getService('database.default.structure'));
		return $service;
	}


	public function createServiceDatabase__default__structure(): Nette\Database\Structure
	{
		$service = new Nette\Database\Structure($this->getService('database.default.connection'),
			$this->getService('cache.storage'));
		return $service;
	}


	public function createServiceEvents__manager(): Kdyby\Events\LazyEventManager
	{
		$service = new Kdyby\Events\LazyEventManager([], $this);
		Kdyby\Events\Diagnostics\Panel::register($service, $this)->renderPanel = true;
		return $service;
	}


	public function createServiceHttp__context(): Nette\Http\Context
	{
		$service = new Nette\Http\Context($this->getService('http.request'), $this->getService('http.response'));
		trigger_error('Service http.context is deprecated.', 16384);
		return $service;
	}


	public function createServiceHttp__request(): Nette\Http\Request
	{
		$service = $this->getService('http.requestFactory')->createHttpRequest();
		return $service;
	}


	public function createServiceHttp__requestFactory(): Nette\Http\RequestFactory
	{
		$service = new Nette\Http\RequestFactory;
		$service->setProxy([]);
		return $service;
	}


	public function createServiceHttp__response(): Nette\Http\Response
	{
		$service = new Nette\Http\Response;
		return $service;
	}


	public function createServiceJsMinFilter(): Joseki\Webloader\JsMinFilter
	{
		$service = new Joseki\Webloader\JsMinFilter;
		return $service;
	}


	public function createServiceLatte__latteFactory(): Nette\Bridges\ApplicationLatte\ILatteFactory
	{
		return new class ($this) implements Nette\Bridges\ApplicationLatte\ILatteFactory {
			private $container;


			public function __construct(Container_d4cafb4653 $container)
			{
				$this->container = $container;
			}


			public function create(): Latte\Engine
			{
				$service = new Latte\Engine;
				$service->setTempDirectory('C:\xampp\htdocs\credit-portal-task\app/../temp/cache/latte');
				$service->setAutoRefresh(true);
				$service->setContentType('html');
				Nette\Utils\Html::$xhtml = false;
				$service->addFilter('ago', $this->container->getService('46_App_Model_Helpers_TimeAgoInWordsFilter'));
				$service->onCompile = $this->container->getService('events.manager')->createEvent(['Latte\Engine', 'onCompile'],
					$service->onCompile, null, false);
				return $service;
			}
		};
	}


	public function createServiceLatte__templateFactory(): Nette\Application\UI\ITemplateFactory
	{
		$service = new Nette\Bridges\ApplicationLatte\TemplateFactory($this->getService('latte.latteFactory'),
			$this->getService('http.request'), $this->getService('security.user'),
			$this->getService('cache.storage'), null);
		return $service;
	}


	public function createServiceMail__mailer(): Nette\Mail\IMailer
	{
		$service = new Nette\Mail\SendmailMailer;
		return $service;
	}


	public function createServiceRouting__router(): Nette\Application\IRouter
	{
		$service = $this->getService('52_App_Router_RouterFactory')->createRouter();
		return $service;
	}


	public function createServiceSecurity__user(): Nette\Security\User
	{
		$service = new Nette\Security\User($this->getService('security.userStorage'), $this->getService('49_App_Model_User_Authenticator'));
		$this->getService('tracy.bar')->addPanel(new Nette\Bridges\SecurityTracy\UserPanel($service));
		$service->onLoggedIn = $this->getService('events.manager')->createEvent(['Nette\Security\User', 'onLoggedIn'],
			$service->onLoggedIn, null, false);
		$service->onLoggedOut = $this->getService('events.manager')->createEvent(['Nette\Security\User', 'onLoggedOut'],
			$service->onLoggedOut, null, false);
		return $service;
	}


	public function createServiceSecurity__userStorage(): Nette\Security\IUserStorage
	{
		$service = new Nette\Http\UserStorage($this->getService('session.session'));
		return $service;
	}


	public function createServiceSession__session(): Nette\Http\Session
	{
		$service = new Nette\Http\Session($this->getService('http.request'), $this->getService('http.response'));
		$service->setExpiration('14 days');
		$service->setOptions(['start' => true]);
		return $service;
	}


	public function createServiceTracy__bar(): Tracy\Bar
	{
		$service = Tracy\Debugger::getBar();
		return $service;
	}


	public function createServiceTracy__blueScreen(): Tracy\BlueScreen
	{
		$service = Tracy\Debugger::getBlueScreen();
		return $service;
	}


	public function createServiceTracy__logger(): Tracy\ILogger
	{
		$service = Tracy\Debugger::getLogger();
		return $service;
	}


	public function createServiceWebloader__cssFrontendCompiler(): WebLoader\Compiler
	{
		$service = new WebLoader\Compiler($this->getService('webloader.cssFrontendFiles'), $this->getService('webloader.cssNamingConvention'),
			'C:\xampp\htdocs\credit-portal-task\www/webtemp');
		$service->setJoinFiles(true);
		$this->getService('webloader.tracyPanel')->addLoader('cssFrontend', $service);
		$service->addFilter($this->getService('wlCssFilter'));
		$service->addFilter($this->getService('cssMinFilter'));
		$service->setCheckLastModified(true);
		return $service;
	}


	public function createServiceWebloader__cssFrontendFiles(): WebLoader\FileCollection
	{
		$service = new WebLoader\FileCollection('C:\xampp\htdocs\credit-portal-task\www/css');
		$service->addFile('bootstrap.min.css');
		$service->addFile('happy.min.css');
		$service->addFile('datagrid.min.css');
		$service->addFile('datagrid-spinners.min.css');
		$service->addFile('style.css');
		$service->addRemoteFiles([]);
		return $service;
	}


	public function createServiceWebloader__cssNamingConvention(): WebLoader\DefaultOutputNamingConvention
	{
		$service = WebLoader\DefaultOutputNamingConvention::createCssConvention();
		return $service;
	}


	public function createServiceWebloader__factory(): WebLoader\Nette\LoaderFactory
	{
		$service = new WebLoader\Nette\LoaderFactory(['frontend' => 'webtemp'], $this->getService('http.request'),
			$this);
		return $service;
	}


	public function createServiceWebloader__jsFrontendCompiler(): WebLoader\Compiler
	{
		$service = new WebLoader\Compiler($this->getService('webloader.jsFrontendFiles'), $this->getService('webloader.jsNamingConvention'),
			'C:\xampp\htdocs\credit-portal-task\www/webtemp');
		$service->setJoinFiles(true);
		$this->getService('webloader.tracyPanel')->addLoader('jsFrontend', $service);
		$service->setCheckLastModified(true);
		return $service;
	}


	public function createServiceWebloader__jsFrontendFiles(): WebLoader\FileCollection
	{
		$service = new WebLoader\FileCollection('C:\xampp\htdocs\credit-portal-task\www/js');
		$service->addFile('bootstrap.min.js');
		$service->addFile('nette.ajax.js');
		$service->addFile('nette.init.js');
		$service->addFile('confirm.ajax.js');
		$service->addFile('form-protection.ajax.js');
		$service->addFile('happy.ajax.js');
		$service->addFile('live-form-validation.js');
		$service->addFile('happy.min.js');
		$service->addFile('datagrid.js');
		$service->addFile('datagrid-spinners.min.js');
		$service->addFile('main.js');
		$service->addRemoteFiles(['https://code.jquery.com/jquery-3.1.1.min.js']);
		return $service;
	}


	public function createServiceWebloader__jsNamingConvention(): WebLoader\DefaultOutputNamingConvention
	{
		$service = WebLoader\DefaultOutputNamingConvention::createJsConvention();
		return $service;
	}


	public function createServiceWebloader__tracyPanel(): WebLoader\Nette\Diagnostics\Panel
	{
		$service = new WebLoader\Nette\Diagnostics\Panel('C:\xampp\htdocs\credit-portal-task\app');
		return $service;
	}


	public function createServiceWlCssFilter(): WebLoader\Filter\CssUrlsFilter
	{
		$service = new WebLoader\Filter\CssUrlsFilter('C:\xampp\htdocs\credit-portal-task\www/');
		return $service;
	}


	public function initialize()
	{
		$this->getService('tracy.bar')->addPanel(new Nette\Bridges\DITracy\ContainerPanel($this));
		$this->getService('events.manager')->createEvent(['Nette\DI\Container', 'onInitialize'])->dispatch($this);
		$this->getService('http.response')->setHeader('X-Powered-By', 'Nette Framework');
		$this->getService('http.response')->setHeader('Content-Type', 'text/html; charset=utf-8');
		$this->getService('http.response')->setHeader('X-Frame-Options', 'SAMEORIGIN');
		$this->getService('session.session')->exists() && $this->getService('session.session')->start();
		Tracy\Debugger::$email = 'jano.vano@gmail.com';
		Tracy\Debugger::$editorMapping = [];
		Tracy\Debugger::setLogger($this->getService('tracy.logger'));
		if ($tmp = $this->getByType("Nette\Http\Session", false)) { $tmp->start(); Tracy\Debugger::dispatch(); };;
		if (!class_exists('WebLoader\LoaderFactory', false)) class_alias('WebLoader\Nette\LoaderFactory', 'WebLoader\LoaderFactory');
	}
}
