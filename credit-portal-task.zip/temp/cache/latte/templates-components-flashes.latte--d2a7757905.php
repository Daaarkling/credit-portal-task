<?php
// source: C:\xampp\htdocs\credit-portal-task\app\presenters\templates\components\flashes.latte

use Latte\Runtime as LR;

class Templated2a7757905 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		$iterations = 0;
		foreach ($flashes as $flash) {
			?><div class="alert alert-<?php echo LR\Filters::escapeHtmlAttr($flash->type) /* line 1 */ ?> alert-dismissible fade show" role="alert">
	<?php echo LR\Filters::escapeHtmlText($flash->message) /* line 2 */ ?>

	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div><?php
			$iterations++;
		}
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['flash'])) trigger_error('Variable $flash overwritten in foreach on line 1');
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}

}
