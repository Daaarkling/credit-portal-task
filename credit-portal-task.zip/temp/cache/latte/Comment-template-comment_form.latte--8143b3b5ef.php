<?php
// source: C:\xampp\htdocs\credit-portal-task\app\controls\Comment/template/comment_form.latte

use Latte\Runtime as LR;

class Template8143b3b5ef extends Latte\Runtime\Template
{
	public $blocks = [
		'_flashes' => 'blockFlashes',
		'_commentForm' => 'blockCommentForm',
		'_commentSign' => 'blockCommentSign',
	];

	public $blockTypes = [
		'_flashes' => 'html',
		'_commentForm' => 'html',
		'_commentSign' => 'html',
	];


	function main()
	{
		extract($this->params);
?>
<div id="comment-form-wrapper" class="my-3 p-3 bg-white rounded box-shadow mt-5">

<div id="<?php echo htmlSpecialChars($this->global->snippetDriver->getHtmlId('flashes')) ?>"><?php $this->renderBlock('_flashes', $this->params) ?></div>
<?php
		if ($user->isLoggedIn()) {
			if (!$user->identity->data['disabled']) {
?>
			<h5 class="pb-2 mb-2">Komentovat</h5>
			<p class="text-muted">
				Příspěvky píši tak, aby se nikoho nedotkly, neponížily, nebyly zbytečně ironické, naopak se snažím být milý, nápomocný a konstruktivní. Žádám, aby v opačném případě byl příspěvek smazán.
			</p>
<div id="<?php echo htmlSpecialChars($this->global->snippetDriver->getHtmlId('commentForm')) ?>"><?php $this->renderBlock('_commentForm', $this->params) ?></div><?php
			}
			else {
?>
			<p class="text-muted mb-0">Z tohoto účtu nemůžete přidávat příspěvky.</p>
<?php
			}
		}
		else {
?>
		<p class="text-muted">Pro možnost přidávání příspěvků je nejprve nutné se přihlásit.</p>
<div id="<?php echo htmlSpecialChars($this->global->snippetDriver->getHtmlId('commentSign')) ?>"><?php $this->renderBlock('_commentSign', $this->params) ?></div><?php
		}
		?></div><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	function blockFlashes($_args)
	{
		extract($_args);
		$this->global->snippetDriver->enter("flashes", "static");
		/* line 4 */
		$this->createTemplate('../../../presenters/templates/components/flashes.latte', $this->params, "include")->renderToContentType('html');
		$this->global->snippetDriver->leave();
		
	}


	function blockCommentForm($_args)
	{
		extract($_args);
		$this->global->snippetDriver->enter("commentForm", "static");
		$form = $_form = $this->global->formsStack[] = $this->global->uiControl["commentForm"];
		?>				<form class="ajax"<?php
		echo Nette\Bridges\FormsLatte\Runtime::renderFormBegin(end($this->global->formsStack), array (
		'class' => NULL,
		), false) ?>>
					

					<div class="form-row">
						<div class="form-group col-md-12">
							<?php if ($_label = end($this->global->formsStack)["text"]->getLabel()) echo $_label ?>

							<textarea rows="8" class="form-control"<?php
		$_input = end($this->global->formsStack)["text"];
		echo $_input->getControlPart()->addAttributes(array (
		'rows' => NULL,
		'class' => NULL,
		))->attributes() ?>><?php echo $_input->getControl()->getHtml() ?></textarea>
						</div>
					</div>

					<?php echo end($this->global->formsStack)["comment"]->getControl() /* line 35 */ ?>

					<?php echo end($this->global->formsStack)["firstname"]->getControl() /* line 36 */ ?>

					<?php echo end($this->global->formsStack)["phone"]->getControl() /* line 37 */ ?>


					<button type="submit" class="btn btn-primary"<?php
		$_input = end($this->global->formsStack)["send"];
		echo $_input->getControlPart()->addAttributes(array (
		'type' => NULL,
		'class' => NULL,
		))->attributes() ?>>Poslat</button>
<?php
		echo Nette\Bridges\FormsLatte\Runtime::renderFormEnd(array_pop($this->global->formsStack), false);
?>				</form>
				<p class="text-muted mt-2">Po přidání příspěvku máte ještě 30 min na jeho úpravu popřípadě smazání.</p>
<?php
		$this->global->snippetDriver->leave();
		
	}


	function blockCommentSign($_args)
	{
		extract($_args);
		$this->global->snippetDriver->enter("commentSign", "static");
		$this->createTemplate('../../../presenters/templates/components/form.latte', $this->params, "import")->render();
		$this->renderBlock('bootstrap-form', ['signInForm'] + $this->params, 'html');
		$this->global->snippetDriver->leave();
		
	}

}
