<?php
// source: C:\xampp\htdocs\credit-portal-task\app\presenters/templates/ThreadAdminEdit/add.latte

use Latte\Runtime as LR;

class Template37c75980cb extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
		'title' => 'blockTitle',
		'_form' => 'blockForm',
	];

	public $blockTypes = [
		'content' => 'html',
		'title' => 'html',
		'_form' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>
<main role="main" class="container">

	<div class="d-flex align-items-center p-3 my-3 text-white-50 bg-purple rounded box-shadow">
		<a href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("ThreadAdmin:")) ?>">
			<img class="mr-3" src="<?php echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($basePath)) /* line 6 */ ?>/images/arrow_left.png" alt="arrow-left" width="48" height="48">
		</a>
		<div class="lh-100">
<?php
		$this->renderBlock('title', get_defined_vars());
?>
		</div>
	</div>

	<div class="my-3 p-3 bg-white rounded box-shadow">
<div id="<?php echo htmlSpecialChars($this->global->snippetDriver->getHtmlId('form')) ?>"><?php $this->renderBlock('_form', $this->params) ?></div>	</div>
</main>
<?php
	}


	function blockTitle($_args)
	{
		extract($_args);
?>			<h4 class="mb-0 text-white lh-100">Úprava/přidání vlákna</h4>
<?php
	}


	function blockForm($_args)
	{
		extract($_args);
		$this->global->snippetDriver->enter("form", "static");
		$this->createTemplate('../components/form.latte', $this->params, "import")->render();
		$this->renderBlock('bootstrap-form', ['threadForm'] + $this->params, 'html');
		$this->global->snippetDriver->leave();
		
	}

}
