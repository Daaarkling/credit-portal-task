<?php
// source: C:\xampp\htdocs\credit-portal-task\app\controls\Comment/template/comment_list.latte

use Latte\Runtime as LR;

class Template43709ebcea extends Latte\Runtime\Template
{
	public $blocks = [
		'_flashes' => 'blockFlashes',
		'_comments' => 'blockComments',
	];

	public $blockTypes = [
		'_flashes' => 'html',
		'_comments' => 'html',
	];


	function main()
	{
		extract($this->params);
?>
<div class="my-3 p-3 bg-white rounded box-shadow">

<div id="<?php echo htmlSpecialChars($this->global->snippetDriver->getHtmlId('flashes')) ?>"><?php $this->renderBlock('_flashes', $this->params) ?></div>
<div id="<?php echo htmlSpecialChars($this->global->snippetDriver->getHtmlId('comments')) ?>"><?php $this->renderBlock('_comments', $this->params) ?></div></div><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['comment'])) trigger_error('Variable $comment overwritten in foreach on line 9');
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	function blockFlashes($_args)
	{
		extract($_args);
		$this->global->snippetDriver->enter("flashes", "static");
		/* line 4 */
		$this->createTemplate('../../../presenters/templates/components/flashes.latte', $this->params, "include")->renderToContentType('html');
		$this->global->snippetDriver->leave();
		
	}


	function blockComments($_args)
	{
		extract($_args);
		$this->global->snippetDriver->enter("comments", "static");
		if (count($comments) > 0) {
			$iterations = 0;
			foreach ($iterator = $this->global->its[] = new LR\CachingIterator($comments) as $comment) {
				if (!$user->isLoggedIn() && $comment->getDeleted()) continue;
				if ($user->isInRole('member') && $comment->getDeleted()) continue;
				?>				<div id="<?php echo LR\Filters::escapeHtmlAttr($comment->getId()->toString()) /* line 12 */ ?>"<?php
				if ($_tmp = array_filter([!$iterator->first ? 'pt-3' : NULL, !$iterator->last ? 'border-bottom pb-3' : NULL, $comment->getDeleted() ? 'text-deleted' : NULL, 'row border-gray mb-0'])) echo ' class="', LR\Filters::escapeHtmlAttr(implode(" ", array_unique($_tmp))), '"' ?>>
					<div class="col-md-3 text-center border-right">
						<?php echo LR\Filters::escapeHtmlText($comment->getAuthorName()) /* line 14 */ ?><br>
						<small class="d-block text-muted pt-2"><?php echo LR\Filters::escapeHtmlText(call_user_func($this->filters->date, $comment->getPosted(), 'j. n. Y H:i')) /* line 15 */ ?></small>
						<small class="d-block text-muted"><?php echo LR\Filters::escapeHtmlText(call_user_func($this->filters->ago, $comment->getPosted())) /* line 16 */ ?></small>
<?php
				if (!$comment->getDeleted()) {
					if ($user->isInRole(\App\Model\User\User::ROLE_ADMIN) || (($author = $comment->getAuthor()) && $author->getId()->equals($user->getId()) && $comment->canBeStillModified())) {
						?>							<a class="btn btn-warning btn-sm mt-1 ajax" href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiPresenter->link("edit!", ['commentId' => $comment->getId()->toString()])) ?>#comment-form-wrapper">Upravit</a>
<?php
					}
					if ($user->isInRole(\App\Model\User\User::ROLE_ADMIN) || (($author = $comment->getAuthor()) && $author->getId()->equals($user->getId()) && $comment->canBeStillModified())) {
						?>							<a class="btn btn-danger btn-sm mt-1 ajax" data-confirm="opravdu chcete smazat tento příspěvek?" href="<?php
						echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("delete!", [$comment->getId()->toString()])) ?>">Smazat</a>
<?php
					}
				}
				else {
					?>							<small class="d-block text-muted pt-2 text-deleted-none">Smazáno <?php echo LR\Filters::escapeHtmlText(call_user_func($this->filters->date, $comment->getDeleted(), 'j. n. Y H:i')) /* line 21 */ ?></small>
<?php
				}
?>
					</div>
					<div class="col-md-9">
						<?php echo LR\Filters::escapeHtmlText(call_user_func($this->filters->breaklines, $comment->getText())) /* line 25 */ ?>

					</div>
				</div>
<?php
				$iterations++;
			}
			array_pop($this->global->its);
			$iterator = end($this->global->its);
		}
		else {
?>
			<p class="text-muted mb-0"><i>Zatím nebyl přidán žádný příspěvěk.</i></p>
<?php
		}
		$this->global->snippetDriver->leave();
		
	}

}
