<?php
// source: C:\xampp\htdocs\credit-portal-task\app\presenters/templates/Homepage/default.latte

use Latte\Runtime as LR;

class Template883c7d1700 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['thread'])) trigger_error('Variable $thread overwritten in foreach on line 12');
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>
<main role="main" class="container">

	<div class="d-flex align-items-center p-3 my-3 text-white-50 bg-purple rounded box-shadow">
		<div class="lh-100">
			<h4 class="mb-0 text-white lh-100">Všechna vlákna</h4>
			<small>Pojďte diskutovat</small>
		</div>
	</div>

	<div class="my-3 p-3 bg-white rounded box-shadow">
<?php
		$iterations = 0;
		foreach ($iterator = $this->global->its[] = new LR\CachingIterator($threads) as $thread) {
			if ($thread->getDeleted()) continue;
			?>			<div<?php if ($_tmp = array_filter([!$iterator->first ? 'pt-3' : NULL, !$iterator->last ? 'border-bottom pb-3' : NULL, 'row border-gray mb-0'])) echo ' class="', LR\Filters::escapeHtmlAttr(implode(" ", array_unique($_tmp))), '"' ?>>
				<div class="col-md-8">
					<h5 class="d-block text-gray-dark mb-0">
						<a href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Thread:", [$thread])) ?>"><?php
			echo LR\Filters::escapeHtmlText($thread->getName()) /* line 17 */ ?></a>
					</h5>
					<?php echo LR\Filters::escapeHtmlText($thread->getDescription()) /* line 19 */ ?>

				</div>
				<div class="col-md-1 lh-48px text-center">
					<?php echo LR\Filters::escapeHtmlText($thread->getNumOfComments()) /* line 22 */ ?>

				</div>
				<div class="col-md-3 lh-48px text-center">
<?php
			if (($last = $thread->getLastComment())) {
				?>						<a href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiPresenter->link("Thread:", [$thread])) ?>#<?php
				echo LR\Filters::escapeHtmlAttr(LR\Filters::safeUrl($last->getId()->toString())) /* line 26 */ ?>"><?php
				echo LR\Filters::escapeHtmlText(call_user_func($this->filters->ago, $last->getPosted())) /* line 26 */ ?></a>
<?php
			}
			else {
?>
						<i class="small">Zatím nebyl přidán žádný příspěvěk.</i>
<?php
			}
?>
				</div>
			</div>
<?php
			$iterations++;
		}
		array_pop($this->global->its);
		$iterator = end($this->global->its);
?>
	</div>

	<div class="my-3 p-3 bg-white rounded box-shadow mt-5">
		<h5 class="pb-2 mb-2">Jak se zapojit</h5>
<?php
		if (!$user->isLoggedIn()) {
			?>			<p class="text-muted">Aby jste mohli psát příspěvky je nutné se <a href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Sign:up")) ?>">zaregistrovat</a>, pokud již účet máte nezbývá se než <a href="<?php
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Sign:in")) ?>">příhlásit</a>.</p>
<?php
		}
		else {
			?>			<p class="text-muted">Jste přihlášěn jako <?php echo LR\Filters::escapeHtmlText($user->identity->data['name']) /* line 40 */ ?>. <?php
			if ($user->identity->data['disabled']) {
				?>Tento účet má ZAKÁZÁNO psát příspěvky.<?php
			}
			else {
				?>Z tohoto účtu můžete psát příspěvky.<?php
			}
?></p>
<?php
		}
?>
	</div>

</main>
<?php
	}

}
