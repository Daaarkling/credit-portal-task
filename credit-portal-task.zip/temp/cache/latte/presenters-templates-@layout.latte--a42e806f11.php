<?php
// source: C:\xampp\htdocs\credit-portal-task\app\presenters/templates/@layout.latte

use Latte\Runtime as LR;

class Templatea42e806f11 extends Latte\Runtime\Template
{
	public $blocks = [
		'head' => 'blockHead',
		'_menu' => 'blockMenu',
		'_flashes' => 'blockFlashes',
		'_content' => 'blockContent',
		'scripts' => 'blockScripts',
	];

	public $blockTypes = [
		'head' => 'html',
		'_menu' => 'html',
		'_flashes' => 'html',
		'_content' => 'html',
		'scripts' => 'html',
	];


	function main()
	{
		extract($this->params);
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Credit Portal Task">
	<meta name="author" content="Jan Vaňura">

	<title><?php
		if (isset($this->blockQueue["title"])) {
			$this->renderBlock('title', $this->params, function ($s, $type) {
				$_fi = new LR\FilterInfo($type);
				return LR\Filters::convertTo($_fi, 'html', $this->filters->filterContent('striphtml', $_fi, $s));
			});
			?> | <?php
		}
?>Credit Portal Task</title>

<?php
		/* line 11 */ $_tmp = $this->global->uiControl->getComponent("css");
		if ($_tmp instanceof Nette\Application\UI\IRenderable) $_tmp->redrawControl(null, false);
		$_tmp->render();
?>

	<?php
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('head', get_defined_vars());
?>
</head>

<body class="bg-light">

<nav class="navbar navbar-expand-md fixed-top navbar-dark bg-dark">
	<a class="navbar-brand" href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Homepage:")) ?>">Credit Porta Task</a>
	<button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
		<span class="navbar-toggler-icon"></span>
	</button>


	<div class="navbar-collapse offcanvas-collapse"<?php echo ' id="' . htmlSpecialChars($this->global->snippetDriver->getHtmlId('menu')) . '"' ?>>
<?php $this->renderBlock('_menu', $this->params) ?>
	</div>

</nav>

<div id="<?php echo htmlSpecialChars($this->global->snippetDriver->getHtmlId('flashes')) ?>"><?php $this->renderBlock('_flashes', $this->params) ?></div>
<div id="<?php echo htmlSpecialChars($this->global->snippetDriver->getHtmlId('content')) ?>"><?php $this->renderBlock('_content', $this->params) ?></div>
<?php
		$this->renderBlock('scripts', get_defined_vars());
?>
</body>
</html>

<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	function blockHead($_args)
	{
		
	}


	function blockMenu($_args)
	{
		extract($_args);
		$this->global->snippetDriver->enter("menu", "static");
?>		<ul class="navbar-nav mr-auto">
			<li class="nav-item">
				<a class="nav-link" href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Homepage:")) ?>">Úvod</a>
			</li>
<?php
		if ($user->isInRole('admin')) {
?>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("ThreadAdmin:")) ?>">Vlákna</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("UserAdmin:")) ?>">Uživatelé</a>
				</li>
<?php
		}
?>
		</ul>
		<ul class="navbar-nav">
<?php
		if ($user->isLoggedIn()) {
?>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="dropdown01" aria-haspopup="true" aria-expanded="false"><?php
			echo LR\Filters::escapeHtmlText($user->identity->data['name']) /* line 42 */ ?></a>
					<div class="dropdown-menu" aria-labelledby="dropdown01">
						<a class="dropdown-item" href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Password:")) ?>">Změna hesla</a>
						<a class="dropdown-item" href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("signOut!")) ?>">Odhlásit se</a>
					</div>
				</li>
<?php
		}
		else {
?>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Sign:in")) ?>">Přihlášení</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Sign:up")) ?>">Registrace</a>
				</li>
<?php
		}
?>
		</ul>
<?php
		$this->global->snippetDriver->leave();
		
	}


	function blockFlashes($_args)
	{
		extract($_args);
		$this->global->snippetDriver->enter("flashes", "static");
		if (count($flashes) > 0) {
?>	<div class="container mt-2">
		<?php
			/* line 63 */
			$this->createTemplate('./components/flashes.latte', $this->params, "include")->renderToContentType('html');
?>

	</div>
<?php
		}
		$this->global->snippetDriver->leave();
		
	}


	function blockContent($_args)
	{
		extract($_args);
		$this->global->snippetDriver->enter("content", "static");
		$this->renderBlock('content', $this->params, 'html');
		$this->global->snippetDriver->leave();
		
	}


	function blockScripts($_args)
	{
		extract($_args);
		/* line 72 */ $_tmp = $this->global->uiControl->getComponent("js");
		if ($_tmp instanceof Nette\Application\UI\IRenderable) $_tmp->redrawControl(null, false);
		$_tmp->render();
		
	}

}
