<?php
declare(strict_types=1);

namespace App\Model\Thread;


class ThreadDuplicateSlugException extends \Exception
{
}