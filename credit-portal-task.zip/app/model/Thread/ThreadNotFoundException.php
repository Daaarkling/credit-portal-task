<?php
declare(strict_types=1);

namespace App\Model\Thread;

use App\Model\Db\EntityNotFoundException;


class ThreadNotFoundException extends EntityNotFoundException
{
}