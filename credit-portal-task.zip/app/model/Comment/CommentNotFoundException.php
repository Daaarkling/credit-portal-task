<?php
declare(strict_types=1);

namespace App\Model\Comment;

use App\Model\Db\EntityNotFoundException;


class CommentNotFoundException extends EntityNotFoundException
{
}