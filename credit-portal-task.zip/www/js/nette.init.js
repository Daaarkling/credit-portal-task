$(function(){

	$.nette.init();
});